<script language="JavaScript" type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php
  session_start();
  if($_SESSION['Id'] == null){
    ?>
    <script>
    setTimeout(function () {
      window.location.href = "/";
        }, 0);
    </script>
    <?php
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Кейс 1: команда easy4</title>
  
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>

<body>
<audio id="sound" src="https://eldocode.codechallenge.life/reference/event_sound/sentmessage.mp3"></audio>
<div style="width: 100%;
    height: 38px;
    background: #C4C4C4;
    margin-right: 10px;
    padding: 5px;
    color: white;
    text-shadow: 0 0 3px black;
    font-weight: 300;
    font-size: 18px;">
  <?php 
  session_start();
  echo "<img src='/resource/unknown.png' style='margin-right: 17px; height: -webkit-fill-available;'><img src='https://contestfiles.s3.eu-central-1.amazonaws.com/contests/XIQTEINx_1622202580.png' style='margin-right: 10px; height: -webkit-fill-available;'>";
  ?>
</div>

  <!-- ======= Header ======= -->

      <div class="container" data-aos="fade-up" style="margin: margin: 30px;">

        <div class="section-title">
          <h1>Окно управление чатом</h1> 
        </div>
        <div> 
           <h2>Мои клиенты за <?php echo date("d.m.y");?>:</h2>
            <div>
               <?php 
                  $url = "https://eldocode.makievksy.ru.com/api/Chat?secretKey=MzAxLjAxLjAwMDEgMDowMDowMA==&chatId=1";
               
               ?>

                            
                              <div class="btn-check-menu"  style='background: #d3f1ac;'>
                                <a href="/reference/chatroom" style='text-decoration: none;'>  
                                  <p style="color: black; font-weight: bold; display: inline-block;">
                                    Самойлова Яна 
                                  </p>

                                  <p style="display: inline-block; right: 70; position: absolute; color: black;">
                                    <?php echo date("H:i");?>
                                  </p>
                                  <div>
                                        <p style="color: black; font-size: 15pt; display: inline-block;"> 
                                          Ваш заказ
                                        </p>
                                        <p style="display: inline-block; right: 70; position: absolute; color: black;">
                                          <div style="padding-left: 13px;border-radius: 53px;background: #7dd42f;width: 40px;color: black;height: 40px;padding-top: 3px; right: 70; position: absolute; display: inline-block;">1</div>
                                        </p>
                                    </div>
                                </a>
                              </div>

                              <div class="btn-check-menu"  style='background: #d3f1ac;'>
                                <a href="/reference/chatroom" style='text-decoration: none;'>  
                                  <p style="color: black; font-weight: bold; display: inline-block;">
                                    Даниил Орлов
                                  </p>

                                  <p style="display: inline-block; right: 70; position: absolute; color: black;">
                                    <?php echo date("H:i");?>
                                  </p>
                                  <div>
                                        <p style="color: black; font-size: 15pt; display: inline-block;"> 
                                          Ваш заказ
                                        </p>
                                        <p style="display: inline-block; right: 70; position: absolute; color: black;">
                                          <div style="padding-left: 13px;border-radius: 53px;background: #7dd42f;width: 40px;color: black;height: 40px;padding-top: 3px; right: 70; position: absolute; display: inline-block;">1</div>
                                        </p>
                                    </div>
                                </a>
                              </div>

                              <div class="btn-check-menu"  style='background: #f1acac;'>
                                <a href="#close" style='text-decoration: none;'>  
                                  <p style="color: black; font-weight: bold; display: inline-block;">
                                    Соболев Илья
                                  </p>

                                  <p style="display: inline-block; right: 70; position: absolute; color: black;">
                                    <?php echo "вчера" ;?>
                                  </p>
                                  <div>
                                        <p style="color: black; font-size: 15pt; display: inline-block;"> 
                                          Ваш заказ
                                        </p>
                                        <p style="display: inline-block; right: 70; position: absolute; color: black;">
                                          <div style="padding-left: 13px;border-radius: 53px;background: #7dd42f;width: 40px;color: black;height: 40px;padding-top: 3px; right: 70; position: absolute; display: inline-block;">1</div>
                                        </p>
                                    </div>
                                </a>
                              </div>
                              <div class="btn-check-menu"  style='background: #dadada;'>
                                <a href="#close" style='text-decoration: none;'>  
                                  <p style="color: black; font-weight: bold; display: inline-block;">
                                    Дмитриев Денис
                                  </p>

                                  <p style="display: inline-block; right: 70; position: absolute; color: black;">
                                    <?php echo "вчера ";?>
                                  </p>
                                  <div>
                                        <p style="color: black; font-size: 15pt; display: inline-block;"> 
                                          Заказ на пункте выдачи
                                        </p>
                                        <p style="display: inline-block; right: 70; position: absolute; color: black;">
                                          <div style="padding-left: 5px;border-radius: 53px;background: #7dd42f;width: 40px;color: black;height: 40px;padding-top: 3px; right: 70; position: absolute; display: inline-block;">12</div>
                                        </p>
                                    </div>
                                </a>
                              </div>
            </div>
        </div>


  <script language="JavaScript" type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/waypoints/noframework.waypoints.js"></script>

  <script src="../assets/js/main.js"></script>
</body>
</html> 

