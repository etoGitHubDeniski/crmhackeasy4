<script language="JavaScript" type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<?php
session_start();
var_dump($_SESSION['Id']);
$ClientID = 1;
$ChatId = 1;
$TextData = "Проверка связи от клиента";

// if (isset($_POST['name'])) die($_POST['name']){

        $url = "http://eldocode.makievksy.ru.com/api/Message";
        
        	

        $jsonString = '{
            "Client": 
            {
                "Id": null
            },
            "Text": "'.$_POST['name'].'",
            "Worker": 
            {
                "Id": 5
            },
            "Chat": 
            {
                "Id": '.$ChatId.'
            }
        }';

    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonString); 
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER,
        array(
            'Content-Type:application/json',
            'Accept: text/plain'
        )
    );  
 $html = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    var_dump($jsonString);
    curl_close($ch);

    // } 
?>
