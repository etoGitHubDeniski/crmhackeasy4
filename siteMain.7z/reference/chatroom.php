<script language="JavaScript" type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php
  session_start();
  if($_SESSION['Id'] == null){
    ?>
    <script>
    setTimeout(function () {
      window.location.href = "/";
        }, 0);
    </script>
    <?php
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Кейс 1: команда easy4</title>
  
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>

<body>
<audio id="sound" src="https://eldocode.codechallenge.life/reference/event_sound/sentmessage.mp3"></audio>
<div style="width: 100%;
    height: 38px;
    background: #C4C4C4;
    margin-right: 10px;
    padding: 5px;
    color: white;
    text-shadow: 0 0 3px black;
    font-weight: 300;
    font-size: 18px;">
  <?php 
  session_start();
  echo "<img src='/resource/unknown.png' style='margin-right: 17px; height: -webkit-fill-available;'><img src='https://contestfiles.s3.eu-central-1.amazonaws.com/contests/XIQTEINx_1622202580.png' style='margin-right: 10px; height: -webkit-fill-available;'>";
  ?>
</div>

  <!-- ======= Header ======= -->

      <div class="container" data-aos="fade-up" style="margin: margin: 30px;">

        <div class="section-title">
          <h1>Окно управления чатом</h1> 
        </div>
        <div> 
           <h2>Работа с клиентом <?php echo $_GET['name']; ?>:</h2>

            <iframe src="./viewscreenchat.php" style="width: 100%;height:500px;border: 1px solid grey;">
               Ваш браузер не поддерживает плавающие фреймы!
            </iframe>
         
         
         <form method="POST">
            <input name="messageUser" type="text" id="managerdata" placeholder="Введите сообщение" class="chat-write-text"/>
            <input type="button" id="send" name="myActionName" style="cursor: pointer; width:33%;" value="Отправить" class="chat-button-send">
            <script>
            var musicSpan = document.getElementById('send');
            musicSpan.addEventListener('click',function(){
            document.getElementById('sound').play();
            }
         )
               $("#send").click(
               function() {
                     $.post('./send-data-manager', { name: $("#managerdata").val() } , function(data) {
                        $('#result').html(data);
                     });
                  } 
               );
               </script>
         </form> 

  <script language="JavaScript" type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/waypoints/noframework.waypoints.js"></script>

  <script src="../assets/js/main.js"></script>
</body>
</html> 

