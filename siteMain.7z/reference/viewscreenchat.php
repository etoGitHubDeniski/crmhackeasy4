<!-- <meta http-equiv="refresh" content="5"> -->
<head>
  <link href="/css/style.css" rel="stylesheet">
</head>
<?php
//Данные получамые на чат
session_start();

    $ChatId = 1;
    $ProductOrderId = 2;
    $SecretKey = "MzAxLjAxLjAwMDEgMDowMDowMA==";

//Данные обрабатываемые и выводимые параметры
$getData = "http://eldocode.makievksy.ru.com/api/Message?chatId=".$ChatId."&secretKey=".$SecretKey;
                
function get_project($getData) { 
      $ch = curl_init(); 

      curl_setopt_array($ch,[
        CURLOPT_AUTOREFERER => true,
        CURLOPT_HEADER => false,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_URL => $getData,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER => [
          'Content-Type: application/json'           
        ]
      ]);
      
      $data = curl_exec($ch);
      curl_close($ch); 
      return $data; 
  }
    header("Refresh:5; url=./viewscreenchat");

    $massiveData = json_decode(get_project($getData), true);

        for ($i=0; $i < count($massiveData); $i++) { 
          if(isset($massiveData[$i]["Client"]["Id"])){
            echo "<div class='chat-sender-manager'><div class='chat-datetime'>".$massiveData[$i]["SendDate"]."</div><div>".$massiveData[$i]["Text"]."</div></div>";
          } 
          elseif(isset($massiveData[$i]["Worker"]["Id"]))          
          echo "<div class='chat-sender-client'><div class='chat-datetime'>".$massiveData[$i]["SendDate"]."</div><div>".$massiveData[$i]["Text"]."</div></div>";
          }
        
    
?>