<script language="JavaScript" type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php
  session_start();
  if($_SESSION['Id'] == null){
    ?>
    <script>
    setTimeout(function () {
      window.location.href = "/";
        }, 0);
    </script>
    <?php
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Кейс 1: команда easy4</title>
  <link rel="stylesheet" href="https://fontawesome.com/v4.7/assets/font-awesome/css/font-awesome.css">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <link href="/css/font-awesome.css" rel="stylesheet">
  <link href="/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>

<div style="width: 100%;
    height: 38px;
    background: #C4C4C4;
    margin-right: 10px;
    padding: 5px;
    color: white;
    text-shadow: 0 0 3px black;
    font-weight: 300;
    font-size: 18px;">
  <?php 
  session_start();
  echo "<img src='/resource/unknown.png' style='margin-right: 17px; height: -webkit-fill-available;'><img src='https://contestfiles.s3.eu-central-1.amazonaws.com/contests/XIQTEINx_1622202580.png' style='margin-right: 10px; height: -webkit-fill-available;'>";
  ?>
</div>

  <!-- ======= Header ======= -->

      <div class="container" data-aos="fade-up" style="margin: margin: 30px;">

        <div class="section-title">
          <h1>Окно управления сделкой</h1> 
        </div>
        <div>
            <a href="<?php echo "/main/main-manager" ?>" class="btn-check-menu">Каталог</a>
            <a href="<?php echo "/reference/chat-manager" ?>" class="btn-check-menu">Чат</a>
            <a href="<?php echo "/main/profile" ?>" class="btn-check-menu">Профиль</a>
        </div>

  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/waypoints/noframework.waypoints.js"></script>

  <script src="../assets/js/main.js"></script>

<div>
 <?php
  // include "./levenshtein.php"
 ?>
</div>
</body>

</html> 

