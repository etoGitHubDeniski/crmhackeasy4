<script language="JavaScript" type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php
  session_start();
  if($_SESSION['Id'] == null){
    ?>
    <script>
    setTimeout(function () {
      window.location.href = "/";
        }, 0);
    </script>
    <?php
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Кейс 1: команда easy4</title>
  <link rel="stylesheet" href="https://fontawesome.com/v4.7/assets/font-awesome/css/font-awesome.css">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <link href="/css/font-awesome.css" rel="stylesheet">
  <link href="/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>

<div style="width: 100%;
    height: 38px;
    background: #C4C4C4;
    margin-right: 10px;
    padding: 5px;
    color: white;
    text-shadow: 0 0 3px black;
    font-weight: 300;
    font-size: 18px;">
  <?php 
  session_start();
  echo "<img src='/resource/unknown.png' style='margin-right: 17px; height: -webkit-fill-available;'><img src='https://contestfiles.s3.eu-central-1.amazonaws.com/contests/XIQTEINx_1622202580.png' style='margin-right: 10px; height: -webkit-fill-available;'>";
  ?>
</div>

  <!-- ======= Header ======= -->

      <div class="container" data-aos="fade-up" style="margin: margin: 30px;">

        <div class="section-title">
          <h1>Профиль</h1> 
        </div>

        <div>
            <center>
            <img src="https://contestfiles.s3.eu-central-1.amazonaws.com/contests/XIQTEINx_1622202580.png" style="width:100px;"/>
            <div style="font-weight: bold;
    font-size: 22px;
    margin: 20px;">
                Макиевский Станислав Евгеньевич
            </div>
</center>
        </div>
        <div>
            <div class="btn-check-menu">
                <div>
                    <text style="font-weight: bold;">Адрес магазина</text>
                    <br/>
                    <text>г.Москва, ул. Ленинская д.3</text>
                </div>
            </div>

            <div class="btn-check-menu">
                <div>
                    <text style="font-weight: bold;">Должность</text>
                    <br/>
                    <text>Консультант</text>
                </div>
            </div>

            <a href="/main/succes_order" style="text-decoration: none;">
                <div class="btn-check-menu">
                    <div>
                        <text style="font-weight: bold;">Успешных оформлений за сегодня</text> <text style="right: 60px; position: absolute; top: 500px; font-size: 73pt; color: #cecaca;"> > </text>
                        <br/>
                        <text>4 шт.</text>
                        <br/>
                        <text style="font-weight: bold;">План продаж:</text>
                        <br/>
                        <text><text style="color: #caad11;">53,423 руб. </text> из 100,000 руб.</text>
                    </div>
                </div>
            </a>

            <div class="btn-check-menu">
                <div>
                    <text style="font-weight: bold;">Рабочая почта</text>
                    <br/>
                    <text>burnfeniks@yandex.ru</text>
                </div>
            </div>

            <a href="/" style="text-decoration: none;">
                <div class="btn-check-menu" style="background: #e31235;
    color: white;
    padding-left: 42%;
    font-size: 20pt;
    font-weight: bold;">
                        Выйти
                </div>
            </a>
        </div>

  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/waypoints/noframework.waypoints.js"></script>

  <script src="../assets/js/main.js"></script>

<div>
 <?php
  // include "./levenshtein.php"
 ?>
</div>
</body>

</html> 

