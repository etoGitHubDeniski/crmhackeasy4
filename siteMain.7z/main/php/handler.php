<?php
session_start();

parse_str($_POST['orderlist'], $orderlist);
parse_str($_POST['userdata'], $userdata);

file_put_contents('cart_data_log.txt', var_export($orderlist, 1) . "\r\n");
file_put_contents('cart_data_log.txt', var_export($userdata, 1), FILE_APPEND);

$subject = 'Заказ от '.date('d.m.Y').'г.';

$admin_mail = 'burnfeniks@yandex.ru';

$to = !empty($userdata['user_mail']) ? $userdata['user_mail'] : $admin_mail;

$tbl = '<table style="width: 100%; border-collapse: collapse;">
	<tr>
		<th style="width: 1%; border: 1px solid #333333; padding: 5px;">ID</th>
		<th style="width: 1%; border: 1px solid #333333; padding: 5px;"></th>
		<th style="border: 1px solid #333333; padding: 5px;">Наименование</th>
		<th style="border: 1px solid #333333; padding: 5px;">Цена</th>
		<th style="border: 1px solid #333333; padding: 5px;">Кол-во</th>
	</tr>';
$total_sum = 0;
foreach($orderlist as $id => $item_data) {
	$total_sum += (float)$item_data['count'] * (float)$item_data['price'];
	$tbl .= '
	<tr>
		<td style="border: 1px solid #333333; padding: 5px;">'.$item_data['id'].'</td>
		<td style="border: 1px solid #333333;"><img src="'.$item_data['img'].'" alt="" style="max-width: 64px; max-height: 64px;"></td>
		<td style="border: 1px solid #333333; padding: 5px;">'.$item_data['title'].'</td>
		<td style="border: 1px solid #333333; padding: 5px;">'.$item_data['price'].'</td>
		<td style="border: 1px solid #333333; padding: 5px;">'.$item_data['count'].'</td>
	</tr>';
}
$tbl .= '<tr>
		<td  style="border: 1px solid #333333; padding: 5px;" colspan="3">Итого:</td>
		<td style="border: 1px solid #333333; padding: 5px;"><b>'.$total_sum.'</b></td>
		<td style="border: 1px solid #333333;">&nbsp;</td>
	</tr>
</table>';

//Обработка сессии О КЛИЕНТЕ
$_SESSION['EmailClient'] = $userdata['user_mail'];
$_SESSION['NameClient'] = $userdata['user_name'];

	//Добавление клиента
$urlClient = "http://eldocode.makievksy.ru.com/api/Client";
$arrayClient = json_encode(array(
    "FirstName" => $userdata['user_name'],
    "Email" => $userdata['user_mail']
  ));	

  $ch = curl_init($urlClient);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $arrayClient); 
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_HTTPHEADER,
    array(
        'Content-Type:application/json',
        'Accept: text/plain'
    )
  );  
  $getClientInfo = curl_exec($ch);
  $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  $clientID = json_decode($getClientInfo);
  $_SESSION['ClientID'] = $clientID;
  

//   //Добавление Заказа
//   $urlOrder = "http://eldocode.makievksy.ru.com/api/Order";
// $arrayOrder = json_encode(array(
//     "Client" => $clientID,
//     "Worker" => $_SESSION['Id'],
// 	"Status" => 1,
// 	"Notification" => 1
//   ));	

//   $chOrder = curl_init($urlOrder);
//   curl_setopt($chOrder, CURLOPT_POST, 1);
//   curl_setopt($chOrder, CURLOPT_POSTFIELDS, $arrayOrder); 
   
//   curl_setopt($chOrder, CURLOPT_RETURNTRANSFER, true);
//   curl_setopt($chOrder, CURLOPT_SSL_VERIFYPEER, false);
//   curl_setopt($chOrder, CURLOPT_HEADER, false);
//   curl_setopt($chOrder, CURLOPT_HTTPHEADER,
//     array(
//         'Content-Type:application/json',
//         'Accept: text/plain'
//     )
//   );  
//   $getOrder = curl_exec($chOrder);
// curl_close($chOrder);
// $_SESSION['Order'] = $getOrder;

// //Добавление продукта на выдачу
// $urlProductOrder = "http://eldocode.makievksy.ru.com/api/ProductOrder";
// $arrayProductOrder = json_encode(array(
//     "Order" => $_SESSION['Order'],
//     "Amount" => $item_data['count'],
// 	"Product" => $item_data['title']
//   ));	

//   $chSecretKey = curl_init($urlProductOrder);
//   curl_setopt($chOrder, CURLOPT_POST, 1);
//   curl_setopt($chOrder, CURLOPT_POSTFIELDS, $arrayProductOrder); 
   
//   curl_setopt($chOrder, CURLOPT_RETURNTRANSFER, true);
//   curl_setopt($chOrder, CURLOPT_SSL_VERIFYPEER, false);
//   curl_setopt($chOrder, CURLOPT_HEADER, false);
//   curl_setopt($chOrder, CURLOPT_HTTPHEADER,
//     array(
//         'Content-Type:application/json',
//         'Accept: text/plain'
//     )
//   );  
//   $getSecretKey = curl_exec($chOrder);
// curl_close($chOrder);
// $_SESSION['SecretKey'] = $getSecretKey;



// Тело письма
$body = '
<html>
<head>
  <title>'.$subject.'</title>
</head>
<body>
  <p>Информация о заказчике:</p>
	<ul>
		<li><b>Ф.И.О.:</b> '.$userdata['user_name'].'</li>
		<li><b>Тел.:</b> '.$userdata['user_phone'].'</li>
		<li><b>Email:</b> '.$userdata['user_mail'].'</li>
		<li><b>QR ID:</b> '.$userdata['user_address'].'</li>
		<li><b>Комментарий:</b> '.$userdata['user_comment'].'</li>
	</ul>
	<p>Информация о заказае:</p>
  '.$tbl.'
	<p><a href="https://eldocode.codechallenge.life/main/order-basket">Ссылка на ваш заказ в магазине</a>
	<p><a href="http://eldocode.codechallenge.life/reference/chat">Задайте вопросы по товару или утвердите ваш заказ в чате</a></p>
	<p><strong>Письмо создано автоматически. Пожалуйста, не отвечайте на него!</strong></p>
</body>
</html>';

$headers   = []; 
$headers[] = 'MIME-Version: 1.0'; 
$headers[] = 'Content-type: text/html; charset=utf-8'; 
$headers[] = 'From: easy4 for Eldocode.ru <noreply@easy4.eldocode.ru'; 
$headers[] = 'Bcc: Admin <'.$admin_mail.'>'; 
$headers[] = 'X-Mailer: PHP/'.phpversion();
$send_ok = mail($to, $subject, $body, implode("\r\n", $headers));

$response = [
	'errors' => !$send_ok,
	'message' => $send_ok ? 'Заказ принят в обработку!' : 'Вы совершили ошибку при составлении заявки!'
];
exit( json_encode($response) );

