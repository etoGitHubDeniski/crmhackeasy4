<?php
    session_start();
    
?>

<form class="form-block form-login" action="" method="post">
<img src="./resource/logo-min.jpg" style="width:100%;"/>          
<h2 class="txt-header">Авторизоваться</h2>
    <label style="width: 80px; float: left; font-weight:bold;">Логин</label>
    <br/>
    <input class="input-signin border-style-text" type="text" name="login">
    <br/> 
    <label style="margin-top:20px; width: 100px; float: left; font-weight:bold;">Пароль</label>
    <br/>                        
    <input class="input-signin border-style-text" type="password" name="password">
    <br/>
    <button type="submit" class="brn btn-login-accept" id="signin-button" name="signin-confirm" onclick="">Войти</button>
</form>

<?php 

    if (isset($_REQUEST['signin-confirm'])) {
        $urlProject = "http://eldocode.makievksy.ru.com/api/Worker?login=".$_POST['login']."&password=".$_POST['password'];
                      
        function get_user($urlProject) { 
              $ch = curl_init(); 
       
              curl_setopt_array($ch,[
                CURLOPT_AUTOREFERER => true,
                CURLOPT_HEADER => false,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_URL => $urlProject,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTPHEADER => [
                  'Content-Type: application/json'           
                ]
              ]);
                    
              $data = curl_exec($ch);
              curl_close($ch); 
              return $data; 
          }
          
          $getData = json_decode(get_user($urlProject), true);
          
          if($getData != "The user doesn't exist"){
            $_SESSION['Id'] = $getData['Id']; 
            $_SESSION['Name'] = $getData['FirstName']; 
            $_SESSION['LastName'] = $getData['LastName']; 
            $_SESSION['MiddleName'] = $getData['MiddleName']; 
            ?>
            <script>
            setTimeout(function () {
              window.location.href = "../main/menu-m";
                }, 0);
            </script>
            <?php
          }
          else{
            echo "<center><h1>Такого пользователя нет.</h1></center>";         
          }
    }    
?>