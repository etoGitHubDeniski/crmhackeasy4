<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Документ без названия</title>
<link href="css/jqcart.css" rel="stylesheet" type="text/css">
<script src="js/jquery-1.11.3.min.js"></script>
<script src="js/jqcart.min.js"></script>
<script>
$(function(){
	'use strict';	
	// инициализация плагина
	$.jqCart({
			buttons: '.add_item',
			handler: './php/handler.php',
			cartLabel: '.label-place',
			visibleLabel: true,
			openByAdding: false,
			currency: '&#8381;'
	});	
	// Пример с дополнительными методами
	$('#open').click(function(){
		$.jqCart('openCart'); // открыть корзину
	});
	$('#clear').click(function(){
		$.jqCart('clearCart'); // очистить корзину
	});	
});
</script>
<style type="text/css">
/* Стили для демо (таблица товаров) */
#wrapper {
    width: 100%;
    margin: 10px;
}
#label-place {
    margin: 10px 0;
}
.item_box {
    margin-bottom: 10px;
    padding: 5px;
}
.item_box::after {
  content:'';
  display: table;
  clear: left;
}
.item_box > img {
  float: left;
}
.shopping_list {
    width: 100%;
    margin-top: 10px;
    border-collapse: collapse;
}
.shopping_list td, .shopping_list th {
    padding: 10px;
    border: 1px solid #AAAAAA;
}
</style>

</head>

<body>

<div id="wrapper">
  
<?php 
  $setUrl = "http://eldocode.makievksy.ru.com/api/Product";
  $ch = curl_init(); 
  
  curl_setopt_array($ch,[
    CURLOPT_AUTOREFERER => true,
    CURLOPT_HEADER => false,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_URL => $setUrl,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTPHEADER => [
      'Content-Type: application/json'           
      ]
    ]);
    
    $data = curl_exec($ch);
    curl_close($ch); 
    $getData = json_decode($data, true);
    for ($j=0; $j < count($getData); $j++) { 
    ?>
  <br>
  <div class="item_box">
  	<img style="height: auto; width: 150px;" src="data:image/png;base64, <?php echo $getData[$j]['Photo']?>" alt="">
    <div style="border-radius: 53px;background: #7dd42f;width: 50px;color: black;height: 50px;position: absolute;"></div>
    <h3 class="item_title" style="padding-left: 160px;"><?php echo $getData[$j]['Name']." ".$getData[$j]['Firm']['Name'];?></h3>
    <h5 class="item_title" style="padding-left: 160px;"><?php echo "Арт. ".$getData[$j]['VendorCode'];?></h5>
    <p>Цена: <span class="item_price"><?php echo $getData[$j]['Price']; ?></span>руб.</p>
    <p><strong>Описание товара:</strong> <span class="item_price"><?php echo $getData[$j]['Description']; ?></span></p>
    <button class="add_item btn-buy" data-id="<?php echo $getData[$j]['Id']; ?>" data-title="<?php echo $getData[$j]['Name']." ".$getData[$j]['Firm']['Name'];?>" data-price="<?php echo $getData[$j]['Price']; ?>" data-img="data:image/png;base64, <?php echo $getData[$j]['Photo']?>" data-count="100500">Добавить в корзину</button>
  </div>
<?php
}
?>
  
</p>
<div class="label-place" style="float: right;
    top: 0;
    right: 0;
    position: fixed;
    margin-top: 13px;
    margin-right: 45px;"></div>
</body>
</html>