<?php
// session_start();
// $stack = array();

//    array_push($stack, $_POST['name']);

// var_dump($stack);
?>


<?PHP
//some.php
session_start();
if(isset($_POST['some_name'])){
$_SESSION['some_name'] .= $_POST['some_name'];

var_dump($_SESSION['some_name']);
}
?>

<form action="send-data.php" method="post">
<input type="text" name="some_name" value="<?=(isset($_SESSION['some_name'])) ? $_SESSION['some_name'] : "" ?>">
<input type="submit" value="Send">