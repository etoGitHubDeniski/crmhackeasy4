<?php 


  // api/Product
  $setUrl = "http://eldocode.makievksy.ru.com/api/Product";
  $ch = curl_init(); 
  
  curl_setopt_array($ch,[
    CURLOPT_AUTOREFERER => true,
    CURLOPT_HEADER => false,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_URL => $setUrl,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTPHEADER => [
      'Content-Type: application/json'           
      ]
    ]);
    
    $data = curl_exec($ch);
    curl_close($ch); 
    $getData = json_decode($data, true);
    // var_dump($getData);
    // var_dump($getData);
    
echo "<table>";
for ($j=0; $j < count($getData); $j++) { 
          echo "<tr>";
            echo '<td>';
              echo "<div style='height:200px; border: 2px solid black; margin:5px;'>";
                ?>
                  <img src="/resource/icon.png" style="width:200px; height:200px; display:inline-block;float:left;" />
                  <div style="display:inline-block;">
                      <?php echo "<text style='font-size:10pt; color:gray;'>".$getData[$j]['VendorCode']."</text>";?>
                      <br/>
                      <?php echo $getData[$j]['Name']." ".$getData[$j]['Firm']['Name'];?>
                      <br/>
                      <form method="POST">
                      <text id="data"><?php echo $getData[$j]['Price'];?></text>
                        <input type="button" value='<?php echo $getData[$j]['Price'];?>' id='send'/>

                        <script>
                        $("#send").click(
                        function() {
                              $.post('./send-data', { name: $("#send").val() } , function(data) {
                                $('#result').html(data);
                              });
                          } 
                        );
                        </script>
                      </form>
                  </div>
                <?php
              echo "</div>";
            echo "</td>";
          echo "</tr>";
        }
echo "</table>";
?>