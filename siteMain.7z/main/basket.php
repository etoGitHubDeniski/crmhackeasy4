<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Документ без названия</title>
<link href="css/jqcart.css" rel="stylesheet" type="text/css">
<script src="js/jquery-1.11.3.min.js"></script>
<script>
$(function(){
	'use strict';	
	// инициализация плагина
	$.jqCart({
			buttons: '.add_item',
			handler: './php/handler.php',
			cartLabel: '.label-place',
			visibleLabel: true,
			openByAdding: false,
			currency: '&euro;'
	});	
	// Пример с дополнительными методами
	$('#open').click(function(){
		$.jqCart('openCart'); // открыть корзину
	});
	$('#clear').click(function(){
		$.jqCart('clearCart'); // очистить корзину
	});	
});
</script>
<style type="text/css">
/* Стили для демо (таблица товаров) */
#wrapper {
    width: 100%;
    margin: 10px;
}
#label-place {
    margin: 10px 0;
}
.item_box {
    margin-bottom: 10px;
    padding: 5px;
}
.item_box::after {
  content:'';
  display: table;
  clear: left;
}
.item_box > img {
  float: left;
}
.shopping_list {
    width: 100%;
    margin-top: 10px;
    border-collapse: collapse;
}
.shopping_list td, .shopping_list th {
    padding: 10px;
    border: 1px solid #AAAAAA;
}
</style>

</head>

<body>

<div id="wrapper">
  
<?php 
  $setUrl = "http://eldocode.makievksy.ru.com/api/Product";
  $ch = curl_init(); 
  
  curl_setopt_array($ch,[
    CURLOPT_AUTOREFERER => true,
    CURLOPT_HEADER => false,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_URL => $setUrl,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTPHEADER => [
      'Content-Type: application/json'           
      ]
    ]);
    
    $data = curl_exec($ch);
    curl_close($ch); 
    $getData = json_decode($data, true);
    ?>
  <br>
  <div class="item_box">
  	<img style="height: auto; width: 150px;" src="data:image/png;base64, <?php echo $getData[0]['Photo']?>" alt="">
    <h3 class="item_title" style="padding-left: 160px;"><a href="https://www.mvideo.ru/products/smartfon-xiaomi-redmi-9-4-64gb-carbon-grey-30050582" target="_blank"><?php echo $getData[0]['Name']." ".$getData[0]['Firm']['Name'];?></a></h3>
    <h5 class="item_title" style="padding-left: 160px;"><?php echo "Арт. ".$getData[0]['VendorCode'];?></h5>
    <p>Цена: <span class="item_price"><?php echo $getData[0]['Price']; ?></span>руб.</p>
    <p><strong>Описание товара:</strong> <span class="item_price"><?php echo $getData[0]['Description']; ?></span></p>
  </div>
  <div style="font-weight: bold;">Страница: <a href="#"><div style="margin-top: 75px; width: 30px; padding: 5px 5px 5px 10px; background: #e31235; color: white; font-weight: bold; display: inline-block;">1</div></a></div>
  <div><h2>С этим товаром покупают:</h2></div>
  <br/>
  <center>
  <div style="
    background: white;
    border-radius: 20px;
">
  <div style="display: inline-block; margin:15px;" >
      <img src="https://img.mvideo.ru/Pdb/50043614m.jpg"/>
      <div style="width: 150px;">Кабель AUX InterStep 3.5mm 1m Black (IS-DC-AUDJKJK01-000B201)</div>
      <a href="https://www.mvideo.ru/products/kabel-aux-interstep-3-5mm-1m-black-is-dc-audjkjk01-000b201-50043614" target="_blank"><button style=" background: #e31235;color: white;width: 130px;height: 45px;border: transparent;margin: 15px;">Купить</button></a></p>
  </div>

  <div style="display: inline-block; margin:15px;">
      <img src="https://img.mvideo.ru/Pdb/50143232m.jpg"/>
      <div style="width: 150px;"> Наушники True Wireless Xiaomi Earphones 2 Basic (BHR4089GL)</div> <a href="https://www.mvideo.ru/products/naushniki-true-wireless-xiaomi-earphones-2-basic-bhr4089gl-50143232" target="_blank"><button style=" background: #e31235;color: white;width: 130px;height: 45px;border: transparent;margin: 15px;">Купить</button></a></p>
  </div>

  <div style="display: inline-block; margin:15px;">
      <img src="https://img.mvideo.ru/Pdb/50130833m.jpg"/>
      <div style="width: 150px;"> Кабель USB Type-C Red Line 1м, White (УТ000009459)</div>
      <a href="https://www.mvideo.ru/products/kabel-usb-type-c-red-line-1m-white-ut000009459-50130833" target="_blank"><button style=" background: #e31235;color: white;width: 130px;height: 45px;border: transparent;margin: 15px;">Купить</button></a></p>
  </div>

  <div style="display: inline-block; margin:15px;">
      <img src="https://img.mvideo.ru/Pdb/6011776m.jpg"/>
      <div style="width: 150px;"> Антивирус для смартфона AVAST Mobile Security Ultimate на 1 устройство на 1 год</div>
      
      <a href="https://www.mvideo.ru/products/antivirus-dlya-smartfona-avast-mobile-security-ultimate-na-1-ustroistvo-na-1-god-6011776" target="_blank"><button style=" background: #e31235;color: white;width: 130px;height: 45px;border: transparent;margin: 15px;">Купить</button></a></p>
  </div>
  </div>
  </center>

  
</p>
<div class="label-place" style="float: right;
    top: 0;
    right: 0;
    position: fixed;
    margin-top: 13px;
    margin-right: 45px;"></div>
</body>
</html>