<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Кейс 1: команда easy4</title>
  
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">
  <link href="./css/style.css" rel="stylesheet">
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="<?php echo "/";?>">easy4</a></h1>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Главная страница</a></li>
          <li><a class="nav-link scrollto" href="#login">
            Авторизоваться</a></li>
          <li><a class="nav-link scrollto" href="#team">Команда разработчиков</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>

    </div>
  </header>

  
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
          <h1>ЦИФРОВОЙ ОПЫТ КОНСУЛЬТАЦИЙ В РОЗНИЧНОМ МАГАЗИНЕ</h1>
          <h2>Инструмент, при помощи, которого консультант может сформировать во время консультации
с клиентом список товаров и по завершению отправить клиенту вместе с личной электронной визиткой.</h2>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="#" class="btn-get-started scrollto">Авторизоваться</a>
            <a href="https://youtu.be/z02dzQ6Xly4" class="glightbox btn-watch-video"><i class="bi bi-play-circle"></i><span>Проморолик</span></a>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="./resource/logo.png" class="img-fluid animated" alt="" style="    border-radius: 20px;
    box-shadow: 0px 0px 14px 1px #8a8a8a">
        </div>
      </div>
    </div>

  </section>

  <section id="login" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
            <!-- ЗАГОЛОВОК -->
        </div>

        <div class="row content"
        style="height:400px;">
          <center>
            <?php include "./main/page-login.php";?>
          </center>
        </div>

      </div>
    </section>
  
  <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Команда easy4</h2>
          <p>Команда способна разработать абсолютно любые интерфейсы и иснструменты.</p>
        </div>

        <div class="row">

          <div class="col-lg-6">
            <div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="100">
              <div class="pic"><img src="./resource/stas.png" class="img-fluid" alt="Макиевский Станислав easy4"></div>
              <div class="member-info">
                <h4>Макиевский Станислав</h4>
                <span>Product Manager</span>
                <ul style="margin-top:10px;">
                <li>Архитектор</li>
                <li>.Net Developer</li>
                <li>Web</li>
                </ul>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4 mt-lg-0">
            <div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="200">
              <div class="pic"><img src="./resource/yana.png" class="img-fluid" alt="Самойлова Яна easy4"></div>
              <div class="member-info">
                <h4>Самойлова Яна</h4>
                <span>.Net Developer</span>
                <ul style="margin-top:10px;">
                <li>Разработка Desktop-приложений</li>
                <li>WebAPI</li>
                </ul>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4">
            <div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="300">
              <div class="pic"><img src="./resource/deniska.png"" class="img-fluid" alt="Дмитриев Денис easy4"></div>
              <div class="member-info">
                <h4>Дмитриев Денис</h4>
                <span>Дизайнер</span>
                <ul style="margin-top:10px;">
                <li>Дизайнер</li>
                <li>Frontend: Web, Desktop</li>
                </ul>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4">
            <div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="400">
              <div class="pic"><img src="./resource/ilya.png" class="img-fluid" alt="Соболев Илья easy4"></div>
              <div class="member-info">
                <h4>Соболев Илья</h4>
                <span>Backend</span>
                <ul style="margin-top:10px;">
                  <li>WebAPI</li>
                  <li>SQL</li>
                </ul>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>


  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/waypoints/noframework.waypoints.js"></script>

  <script src="../assets/js/main.js"></script>

</body>

</html>