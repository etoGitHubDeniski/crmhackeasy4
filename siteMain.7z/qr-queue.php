<?php
$unickCode = "G";

          $url = "http://eldocode.makievksy.ru.com/api/Notification";
        
          $jsonString = '{
            "Zone": "'.$unickCode.'"
        }';

       $ch = curl_init($url);
  
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonString); 
      
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_HEADER, false);
      curl_setopt($ch, CURLOPT_HTTPHEADER,
          array(
              'Content-Type:application/json',
              'Accept: text/plain'
          )
      );  
  $html = curl_exec($ch);
  $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  
  $getData = json_decode($html);
      curl_close($ch);
?>

<html>
      <head>      
        <title>Уникальный ключ очереди</title>
        <link rel="stylesheet" href="./css/style.css" type="text/css">
      </head>
      <body>
      <center><img class="screen-logo" src="./resource/logo.png" />
        <h1 class="fnt-qr">Ваш уникальный ключ очереди:</h1>
        <h1 class="fnt-qr-number"><?php echo $unickCode.$getData;?></h1></center>
      </body>
</html>

<?php 
$emailManager = "eldohack@yandex.ru";
  $headers  = "MIME-Version: 1.0\r\n";
  $headers .= "Content-type: text/html; charset=utf-8\r\n";
  $headers .= "From: <service@easy4.eldohack.ru>\r\n";
  $message = '
              <html>
                  <head>
                      <title>Вас ожидает клиент в торговом зале</title>
                  </head>
                  <body>  Вам назначен клиент с номером '.$unickCode.$getData.'
                  </body>
              </html>
              ';
                      if (mail($emailManager, "Вас ожидает клиент", $message, $headers)) {
                            echo "<h1 style='fnt-qr'>Скоро к вам прийдет менеджер из зала. Ожидайте.</h1>";
                        }
?>