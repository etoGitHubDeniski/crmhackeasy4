//
//  EventModel.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import Foundation


struct EventModel: Hashable, Identifiable{
    let id = UUID().uuidString
    let name: String
    let card: [CardEventModel]
}

struct CardEventModel: Hashable, Identifiable{
    let id = UUID().uuidString
    let title: String
    let description: [String]
    let dateStart: String
    let dateEnd: String
    let staff: [StaffModel]
}


