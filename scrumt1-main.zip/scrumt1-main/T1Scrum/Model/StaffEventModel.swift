//
//  StaffEventModel.swift
//  T1Scrum
//
//  Created by Не Busyg on 21.08.2021.
//

import Foundation


struct StaffModel: Hashable, Identifiable, Codable{
    var id: Int?
    let firstName: String?
    let lastName: String?
    let middleName: String
    let email: String?
    let role: RoleModel?
    enum CodingKeyUser: String, CodingKey{
        case id = "Id"
        case firstName = "FirstName"
        case lastName = "LastName"
        case middleName = "MiddleName"
        case email = "Email"
        case role = "Role"
    }
}

struct RoleModel: Hashable, Identifiable, Codable{
    let name: String?
    let id: Int?
    enum CodingKeyRole: String, CodingKey{
        case name = "Name"
        case id = "Id"
    }
}
