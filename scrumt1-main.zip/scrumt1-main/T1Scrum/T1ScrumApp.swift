//
//  T1ScrumApp.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import SwiftUI

@main
struct T1ScrumApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
