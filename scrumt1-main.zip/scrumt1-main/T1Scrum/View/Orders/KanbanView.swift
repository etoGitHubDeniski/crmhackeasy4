//
//  KanbanView.swift
//  T1Scrum
//
//  Created by Не Busyg on 21.08.2021.
//

import SwiftUI

struct KanbanView: View {
    var body: some View {
        VStack{
            
        }
        .navigationTitle("//title card")
    }
}

struct KanbanView_Previews: PreviewProvider {
    static var previews: some View {
        KanbanView()
    }
}
