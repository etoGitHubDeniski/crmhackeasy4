//
//  MainDashboardView.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import SwiftUI

struct MainDashboardView: View {
    @Environment(\.colorScheme) var colorScheme
    var body: some View {
        NavigationView{
            ScrollView(.vertical, showsIndicators: false, content: {
                VStack{
                    
                    HStack(spacing: 0){
                        Menu {
                            //datepicker
                            Button(action: {
                                
                            }, label: {
                                Text("Button")
                            })
                        } label: {
                            HStack{
                                Text("20 августа")
                                    .font(.title2)
                                    .fontWeight(.semibold)
                                Image(systemName: "chevron.down")
                                    .font(.system(size: 14))
                            }
                            .foregroundColor(colorScheme == .light ? Color.black : Color.white)
                        }
                        Spacer()
                        Button {
                            
                        } label: {
                            Image(systemName: "plus")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(colorScheme == .light ? Color.black : Color.white)
                                .frame(width: 42, height: 42)
                                .background(colorScheme == .light ? Color.black.opacity(0.1) : Color.white.opacity(0.1))
                                .cornerRadius(12)
                                .shadow(color: colorScheme == .dark ? Color.black.opacity(0.18) : Color.white.opacity(0.18), radius: 15)
                        }
                        
                    }
                    .padding(.horizontal, 20)
                    .padding(.top)
                    VStack(spacing: 20){
                        ForEach(0..<4){card in
                            HStack(spacing: 15){
                                ZStack{
                                Circle()
                                    .frame(width: 45, height: 45)
                                    .foregroundColor(colorScheme == .dark ? Color.black : Color.white)
                                    .overlay(Circle().stroke(lineWidth: 6).foregroundColor(Color.green))
                                    Text("100%")
                                        .font(.system(size: 12))
                                        .fontWeight(.black)
                                        .foregroundColor(colorScheme == .dark ? Color.white : Color.black)
                                }
                                VStack(alignment: .leading, spacing: 8){
                                    Text("Title")
                                        .font(.title3)
                                        .fontWeight(.semibold)
                                    Text("12 августа")
                                        .font(.caption2)
                                        .fontWeight(.semibold)
                                        .foregroundColor(colorScheme == .dark ? Color.white.opacity(0.6) : Color.black.opacity(0.6))
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                                Button(action: {
                                    
                                }, label: {
                                   Image(systemName: "chevron.right")
                                    .foregroundColor(colorScheme == .dark ? Color.white : Color.black)
                                })
                                
                            }
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(colorScheme == .light ? Color.white: Color.black)
                            .cornerRadius(12)
                            .padding(.vertical)
                            .padding(.horizontal, 20)
                            .shadow(color: colorScheme == .light ? Color.black.opacity(0.16) : Color.white.opacity(0.16), radius: 10)
                        }
                    }
                }
            })
            .navigationTitle("Заявки")
        }
        
    }
}
