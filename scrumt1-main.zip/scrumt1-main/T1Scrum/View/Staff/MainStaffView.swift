//
//  MainStaffView.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import SwiftUI

struct MainStaffView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct MainStaffView_Previews: PreviewProvider {
    static var previews: some View {
        MainStaffView()
    }
}
