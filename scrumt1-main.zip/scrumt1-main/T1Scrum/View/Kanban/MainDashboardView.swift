//
//  MainDashboardView.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import SwiftUI

struct MainDashboardView: View {
    var body: some View {
        VStack{
          Text("dashboard")
        }
    }
}

struct MainDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        MainDashboardView()
    }
}
