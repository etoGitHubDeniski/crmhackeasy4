//
//  RootView.swift
//  T1Scrum
//
//  Created by Не Busyg on 21.08.2021.
//

import SwiftUI

struct RootView: View {
    @State var selected = 1
    var body: some View {
        if selected == 1{
            AuthView(selected: $selected)
        } else {
            MainTabView()
        }
    }
}

struct RootView_Previews: PreviewProvider {
    static var previews: some View {
        RootView()
    }
}
