//
//  CreateEventView.swift
//  T1Scrum
//
//  Created by Не Busyg on 21.08.2021.
//

import SwiftUI

struct CreateEventView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme
    @Binding var showCreateView: Bool
    @State var taskName = ""
    var body: some View {
        VStack{
            HStack{
                Spacer()
                Button(action: {
                    showCreateView.toggle()
                }, label: {
                    Image(systemName: "xmark")
                        .foregroundColor(Color.white)
                        .font(.system(size: 16, weight: .semibold))
                })
            }
            .overlay(Text("Создать событие").font(.title3).foregroundColor(Color.white).fontWeight(.semibold))
            .padding(20)
            .background(Color.init(#colorLiteral(red: 0, green: 0.2680994272, blue: 0.6724529266, alpha: 1)).edgesIgnoringSafeArea(.top))
            VStack(alignment: .leading, spacing: 10){
                Text("Название события")
                    .font(.title3)
                    .fontWeight(.semibold)
                TextField("", text: $taskName)
                    .font(.title3)
                    .padding(.vertical, 8)
                    .padding(.horizontal, 5)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(lineWidth: 0.4).foregroundColor(Color.black.opacity(0.2)))
            }
            .padding()
            HStack(spacing: 12){
                VStack(alignment: .leading, spacing: 10){
                    Text("Начало события")
                        .font(.title3)
                        .fontWeight(.semibold)
                    TextField("", text: $taskName)
                        .font(.title3)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 5)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(lineWidth: 0.4).foregroundColor(Color.black.opacity(0.2)))
                }
                VStack(alignment: .leading, spacing: 10){
                    Text("Конец события")
                        .font(.title3)
                        .fontWeight(.semibold)
                    TextField("", text: $taskName)
                        .font(.title3)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 5)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(lineWidth: 0.4).foregroundColor(Color.black.opacity(0.2)))
                }
            }
            .padding()
            VStack(alignment: .leading, spacing: 10){
                Text("Участники")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .padding(.top)
                    .padding(.leading)
                HStack{
                    ScrollView(.horizontal, showsIndicators: false, content: {
                        HStack{
                            Button {
                                
                            } label: {
                                Image(systemName: "plus")
                                    .font(.system(size: 13, weight: .semibold))
                                    .foregroundColor(colorScheme == .light ? Color.black : Color.white)
                                    .frame(width: 42, height: 42)
                                    .background(colorScheme == .light ? Color.black.opacity(0.1) : Color.white.opacity(0.1))
                                    .cornerRadius(12)
                                    .shadow(color: colorScheme == .dark ? Color.black.opacity(0.18) : Color.white.opacity(0.18), radius: 15)
                            }
                            ForEach(0..<3){item in
                                
                            }
                        }
                        .padding(.horizontal)
                    })
                }
                .padding(.bottom)
            }
            
            Spacer(minLength: 0)

        }
        .onDisappear{
            print("Closed")
        }
    }
}


struct StaffEventCardView: View{
    var model: StaffModel
    var body: some View{
        HStack{
            Image("\(model.firstName?.first)")
                .padding()
                .background(Circle().foregroundColor(Color.black.opacity(0.1)))
            Text(model.middleName ?? "Ivenov")
                .font(.title3)
                .fontWeight(.medium)
            Button(action: {
                
            }, label: {
                Image(systemName: "xmark")
                    .font(.system(size: 12))
            })
        }
        .padding()
        .cornerRadius(10)
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(lineWidth: 0.4).foregroundColor(Color.black.opacity(0.2)))
    }
}
