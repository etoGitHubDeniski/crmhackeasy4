//
//  MainCalendarView.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import SwiftUI

struct MainCalendarView: View {
    @EnvironmentObject var eventViewModel: EventViewModel
    @Environment(\.colorScheme) var colorScheme
    var body: some View {
        
        NavigationView{
            EventsView().environmentObject(eventViewModel)
            .navigationBarBackButtonHidden(true)
           .navigationTitle("События")
        }
    }
}


