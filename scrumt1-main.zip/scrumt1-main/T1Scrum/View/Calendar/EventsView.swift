//
//  EventsView.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import SwiftUI

struct EventsView: View {
    @EnvironmentObject var eventViewModel: EventViewModel
    @Environment(\.colorScheme) var colorScheme
    @State var selection = Date()
    @State var selectedListCard = 0
    @State var selectedModel: EventModel = EventModel(name: "", card: [CardEventModel(title: "", description: [""], dateStart: "", dateEnd: "", staff: [StaffEventModel(name: "", image: "")])])
    var body: some View {
        ScrollView(.vertical, showsIndicators: false){
            VStack(spacing: 0){
                HeaderEventsView(selection: $selection)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8){
                        ForEach(0..<eventViewModel.eventModel.count, id: \.self){ card in
                            ListEventCardView(viewModel: eventViewModel, model: eventViewModel.eventModel[card], selected: isSelected(index: card, selected: selectedListCard), index: $selectedListCard)
                                .onTapGesture {
                                    withAnimation(.spring()){
                                        selectedListCard = card
                                        selectedModel = eventViewModel.eventModel[card]
                                    }
                                }
                        }
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.vertical)
                LazyVStack{
                    ForEach(eventViewModel.eventModel.filter { $0.id == selectedModel.id }){test in
                        LazyVStack(spacing: 30){
                        ForEach(test.card, id:\.self){ card in
                            EventCardView(modelCard: card)
                        }
                        }
                    }
                }
            }
            .padding(.top, 5)
            .padding(.bottom)
        }
        .fixFlickering()
        .onAppear {
            selectedModel = eventViewModel.eventModel.first!
        }
    }
    func isSelected(index: Int, selected: Int)-> Bool{
        if index == selected{
            return true
        }
        return false
    }
}

struct ListEventCardView: View{
    var viewModel: EventViewModel
    var model: EventModel
    let selected: Bool
    @Binding var index: Int
    var body: some View{
        HStack(spacing: 8){
            Text(model.name)
                .font(.headline)
                .fontWeight(selected ? .semibold : .regular)
                .foregroundColor(selected ? Color.white : Color.black.opacity(0.7))
                .lineLimit(1)
            if selected{
                Button {
                    withAnimation(.spring()){
                        viewModel.eventModel.removeAll(where: { $0.id == model.id })
                        if viewModel.eventModel.count > 1{
                            
                        }
                    }
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 17))
                        .foregroundColor(Color.white)
                }
                
            }
        }
        .padding(.horizontal, 11)
        .padding(.vertical, 7)
        .background(selected ? Color.green : Color.init(#colorLiteral(red: 0.940536797, green: 0.9420795441, blue: 0.9877163768, alpha: 1)))
        .cornerRadius(10)
    }
}

struct HeaderEventsView: View{
    @Environment(\.colorScheme) var colorScheme
    @Binding var selection: Date
    var body: some View{
        HStack(spacing: 0){
            Menu {
                DatePicker("", selection: $selection)
                    .datePickerStyle(CompactDatePickerStyle())
            } label: {
                HStack{
                    Text("20 августа")
                        .font(.title2)
                        .fontWeight(.semibold)
                    Image(systemName: "chevron.down")
                        .font(.system(size: 14))
                }
                .foregroundColor(colorScheme == .light ? Color.black : Color.white)
            }
            Spacer()
            Button {
                
            } label: {
                Image(systemName: "plus")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(colorScheme == .light ? Color.black : Color.white)
                    .frame(width: 42, height: 42)
                    .background(colorScheme == .light ? Color.black.opacity(0.1) : Color.white.opacity(0.1))
                    .cornerRadius(12)
                    .shadow(color: colorScheme == .dark ? Color.black.opacity(0.18) : Color.white.opacity(0.18), radius: 15)
            }
            
        }
        .padding(.horizontal, 20)
        .padding(.top)
    }
}

struct EventCardView: View{
    let dateFormatter = DateFormatter()
    var modelCard: CardEventModel
    @Environment(\.colorScheme) var colorScheme
    var body: some View{
        HStack(spacing: 10){
            Rectangle()
                .frame(width: 10)
                .foregroundColor(Color.green)
            VStack(alignment: .leading, spacing: 10){
                Text(modelCard.title)
                    .font(.title3)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                VStack(spacing: 6){
                    ForEach(modelCard.description, id: \.self){card in
                        Text(card)
                        .font(.callout)
                        .fontWeight(.semibold)
                        .foregroundColor(colorScheme == .light ? Color.black.opacity(0.5) : Color.white.opacity(0.5))
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                }
              
                HStack(spacing: 0){
                HStack(spacing: 0){
                    ForEach(0..<modelCard.staff.count, id: \.self){item in
                    Circle()
                        .frame(width: 30, height: 30)
                        .foregroundColor(Color.red)
                        .overlay(Circle().stroke(lineWidth: 0.5).foregroundColor(Color.white))
                        .offset(x: -CGFloat(item * 10))
                        
                }
                    Spacer()
                    Text("\(modelCard.dateEnd)")
                        .font(.callout)
                        .fontWeight(.semibold)
                }
                }
            }
            .padding(.vertical)
        }
        .padding(.trailing)
        .background(colorScheme == .dark ? Color.black : Color.white)
        .cornerRadius(12)
        .padding(.horizontal, 20)
        .shadow(color: colorScheme == .dark ? Color.white.opacity(0.14) : Color.black.opacity(0.14), radius: 12)
        .onAppear {
            dateFormatter.dateFormat = "MMM d, h:mm a"
        }
    }
}
extension ScrollView {
    private typealias PaddedContent = ModifiedContent<Content, _PaddingLayout>
    
    func fixFlickering() -> some View {
        GeometryReader { geo in
            ScrollView<PaddedContent>(axes, showsIndicators: showsIndicators) {
                content.padding(geo.safeAreaInsets) as! PaddedContent
            }
            .edgesIgnoringSafeArea(.all)
        }
    }
}
