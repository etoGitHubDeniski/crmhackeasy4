//
//  DetailEventView.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import SwiftUI

struct DetailEventView: View {
    var body: some View {
        ZStack{
            VStack{
            Button {
                
            } label: {
                Image(systemName: "chevron.left")
                    
            }
                Spacer()
            }
            .padding(20)
        VStack{
        }
        }
    }
}

struct DetailEventView_Previews: PreviewProvider {
    static var previews: some View {
        DetailEventView()
    }
}
