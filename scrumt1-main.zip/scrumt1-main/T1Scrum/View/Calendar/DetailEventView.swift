//
//  DetailEventView.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import SwiftUI

struct DetailEventView: View {
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.presentationMode) var presentationMode
    var selectedDetailModel: CardEventModel
    
    var body: some View {
        ZStack{
            
            VStack(alignment: .leading){
            Button {
                presentationMode.wrappedValue.dismiss()
            } label: {
                Image(systemName: "chevron.left")
                    .frame(width: 40, height: 40)
                    .foregroundColor(colorScheme == .dark ? Color.white : Color.black)
                    .background(colorScheme == .dark ? Color.black : Color.white)
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(lineWidth: 0.75).foregroundColor(colorScheme == .dark ? Color.white : Color.black))
            }
                Spacer()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(20)
        VStack{
            VStack(alignment: .leading, spacing: 10){
                Text("\(selectedDetailModel.title)")
                    .font(.title)
                    .fontWeight(.bold)
                Text("В процессе с \(selectedDetailModel.dateStart)")
                    .font(.caption2)
                    .foregroundColor(colorScheme == .dark ? Color.white.opacity(0.6) : Color.black.opacity(0.6))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(20)
            .padding(.top, 50)
            Spacer()
        }
        }
    }
}


