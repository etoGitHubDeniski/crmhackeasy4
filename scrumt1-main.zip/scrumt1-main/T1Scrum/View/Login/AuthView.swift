//
//  AuthView.swift
//  T1Scrum
//
//  Created by Не Busyg on 21.08.2021.
//

import SwiftUI

struct AuthView: View {
    @State var login = "ivan"
    @State var password = "1234"
    @Binding var selected: Int
    @Environment(\.colorScheme) var colorScheme
    @StateObject var userViewModel = UserViewModel()
    var body: some View {
        NavigationView{
        VStack{
            HStack(spacing: 0){
                Text("+I ")
                    .font(.system(size: 75, weight: .bold))
                    .foregroundColor(Color.blue)
                Text("EASY4")
                    .font(.system(size: 31, weight: .black))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            VStack(spacing: 14){
                TextField("Login", text: $login)
                    .font(.title3)
                    .padding()
                    .background(colorScheme == .dark ? Color.black.opacity(0.1) : Color.white.opacity(0.1))
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(lineWidth: 0.4).foregroundColor(colorScheme == .dark ? Color.white.opacity(0.2) : Color.black.opacity(0.2)))
                SecureField("Password", text: $password)
                    .font(.title3)
                    .padding()
                    .background(colorScheme == .dark ? Color.black.opacity(0.1) : Color.white.opacity(0.1))
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(lineWidth: 0.4).foregroundColor(colorScheme == .dark ? Color.white.opacity(0.2) : Color.black.opacity(0.2)))
            }
            .padding()
            Spacer(minLength: 0)
            
        
            Button(action: {
                withAnimation{
                selected = 2
                    userViewModel.loginUser(login: login, password: password)
                }
                UserDefaults.standard.setValue("yes", forKey: "auth")
            }, label: {
                Text("Войти")
                    .font(.title2)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .frame(height: 65)
                    .foregroundColor(Color.white)
                    .background(Color.blue)
                    .cornerRadius(15)
                    .padding(.horizontal)
            })
                       
            
            
            .padding(.bottom)

        }
        .navigationTitle("Авторизация")
        }

    }
}

