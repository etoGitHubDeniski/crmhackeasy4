//
//  MainTabView.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import SwiftUI

struct MainTabView: View {
    @StateObject var eventViewModel = EventViewModel()
    @State var selection: Int = 1
    init(){
        UITabBar.appearance().isHidden = true
    }
    var body: some View {
        VStack(spacing: 0){
        TabView(selection: $selection){
            MainDashboardView().tag(1)
            MainCalendarView().environmentObject(eventViewModel).tag(2)
            MainStaffView().tag(4)
            ProfileView().tag(5)
        }
            CustomTabView(selection: $selection)
        }
        .edgesIgnoringSafeArea(.bottom)
    }
}


struct CustomTabView: View{
    @Environment(\.colorScheme) var colorScheme
    @Binding var selection: Int
    var body: some View{
        HStack(spacing: 0){
            Button(action: {
                withAnimation{
                    selection = 1
                }
            }, label: {
                Image(systemName: "list.bullet.below.rectangle")
                    .font(.system(size: 24))
                    
            })
            .foregroundColor(selection == 1 && colorScheme == .light ? Color.black : selection == 1 && colorScheme == .dark ? Color.white : selection != 1 && colorScheme == .light ? Color.black.opacity(0.42) : Color.white.opacity(0.42))
            .frame(maxWidth: .infinity, alignment: .center)
            Button(action: {
                withAnimation{
                    selection = 2
                }
            }, label: {
                Image(systemName: "calendar")
                    .font(.system(size: 24))
                    
            })
            .foregroundColor(selection == 2 && colorScheme == .light ? Color.black : selection == 2 && colorScheme == .dark ? Color.white : selection != 2 && colorScheme == .light ? Color.black.opacity(0.42) : Color.white.opacity(0.42))
            .frame(maxWidth: .infinity, alignment: .center)
            Button(action: {
                withAnimation{
                    selection = 3
                }
            }, label: {
                Image(systemName: "message")
                    .font(.system(size: 24))
                    
            })
            .foregroundColor(selection == 3 && colorScheme == .light ? Color.black : selection == 3 && colorScheme == .dark ? Color.white : selection != 3 && colorScheme == .light ? Color.black.opacity(0.42) : Color.white.opacity(0.42))
            .frame(maxWidth: .infinity, alignment: .center)
            Button(action: {
                withAnimation{
                    selection = 4
                }
            }, label: {
                Image(systemName: "person.3")
                    .font(.system(size: 24))
                    
            })
            .foregroundColor(selection == 4 && colorScheme == .light ? Color.black : selection == 4 && colorScheme == .dark ? Color.white : selection != 4 && colorScheme == .light ? Color.black.opacity(0.42) : Color.white.opacity(0.42))
            .frame(maxWidth: .infinity, alignment: .center)
            Button(action: {
                withAnimation{
                    selection = 5
                }
            }, label: {
                Image(systemName: "person")
                    .font(.system(size: 24))
                    
            })
            .foregroundColor(selection == 5 && colorScheme == .light ? Color.black : selection == 5 && colorScheme == .dark ? Color.white : selection != 5 && colorScheme == .light ? Color.black.opacity(0.42) : Color.white.opacity(0.42))

            .frame(maxWidth: .infinity, alignment: .center)
        }
        .padding(.bottom, 44)
        .padding(.top, 25)
        .padding(.horizontal, 30)
        .background(colorScheme == .dark ? Color.black : Color.white)
        .cornerRadius(25)
        .shadow(color: colorScheme == .dark ? Color.white.opacity(0.16) : Color.black.opacity(0.16), radius: 18)
    }
}


struct MainTabView_Previews: PreviewProvider {
    static var previews: some View {
        MainTabView()
    }
}
