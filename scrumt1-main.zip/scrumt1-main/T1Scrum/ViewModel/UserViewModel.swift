//
//  UserViewModel.swift
//  T1Scrum
//
//  Created by Не Busyg on 21.08.2021.
//

import Foundation
import Alamofire
import SwiftyJSON

class UserViewModel: ObservableObject{
    @Published var userModel: StaffModel = StaffModel(id: 1, firstName: "", lastName: "", middleName: "", email: "", role: RoleModel(name: "", id: 1))
    @Published var roleModel: RoleModel = RoleModel(name: "", id: 1)
    func loginUser(login: String, password: String){
        
        let url = "http://crmhack.makievksy.ru.com/api/Worker?login=\(login)&password=\(password)"
        AF.request(url, method: .get).validate().responseJSON{respone in
            switch respone.result{
            case .success(let value):
                let json = JSON(value)
                print(json)
                do {
                    let roleDecoder = try JSONDecoder().decode(RoleModel.self, from: respone.data!)
                let decoder = try JSONDecoder().decode(StaffModel.self, from: respone.data!)
                    self.roleModel = roleDecoder
                    self.userModel = decoder
                    print(self.userModel)
                }
                catch let error {
                    print(error.localizedDescription)
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
