//
//  EventViewModel.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import Foundation


class EventViewModel: ObservableObject{
    @Published var eventModel: [EventModel] = []
    init(){
        fetchEvents()
    }
    func fetchEvents(){
        self.eventModel = [EventModel(name: "Встреча с клиентом", card: [CardEventModel(title: "Созвон с покупателем", description: ["- Обсудить стоимость работы", "- Назначить встречу"], dateStart: "20 августа, 17:11", dateEnd: "20 августа, 20:11", staff: [StaffEventModel(name: "Uriy", image: "")]), CardEventModel(title: "Созвон с покупателем", description: ["- Обсудить стоимость работы", "- Назначить встречу"], dateStart: "20 августа, 17:11", dateEnd: "20 августа, 20:11", staff: [StaffEventModel(name: "Uriy", image: "")]) , CardEventModel(title: "Созвон с покупателем", description: ["- Обсудить стоимость работы", "- Назначить встречу"], dateStart: "20 августа, 17:11", dateEnd: "20 августа, 20:11", staff: [StaffEventModel(name: "Uriy", image: "")])]), EventModel(name: "Митап", card: [CardEventModel(title: "Цели и задачи", description: ["- Обсудить сроки работы", "- Назначить встречу", "- Созвониться с лидом"], dateStart: "20 августа, 15:11", dateEnd: "20 августа, 16:11", staff: [StaffEventModel(name: "Uriy", image: ""), StaffEventModel(name: "Den", image: "")]),CardEventModel(title: "Цели и задачи", description: ["- Обсудить сроки работы", "- Назначить встречу", "- Созвониться с лидом"], dateStart: "20 августа, 15:11", dateEnd: "20 августа, 16:11", staff: [StaffEventModel(name: "Uriy", image: ""), StaffEventModel(name: "Den", image: "")]),CardEventModel(title: "Цели и задачи", description: ["- Обсудить сроки работы", "- Назначить встречу", "- Созвониться с лидом"], dateStart: "20 августа, 15:11", dateEnd: "20 августа, 16:11", staff: [StaffEventModel(name: "Uriy", image: ""), StaffEventModel(name: "Den", image: "")])]), EventModel(name: "Тимбилдинг", card: [CardEventModel(title: "Обсудить план тимбилдинга", description: ["- Найти место для проведения", "- Назначить дату"], dateStart: "20 августа, 11:11", dateEnd: "20 августа, 14:11", staff: [StaffEventModel(name: "Uriy", image: ""), StaffEventModel(name: "Uriy", image: ""),StaffEventModel(name: "Uriy", image: ""),StaffEventModel(name: "Uriy", image: "")])])]
    }
}
