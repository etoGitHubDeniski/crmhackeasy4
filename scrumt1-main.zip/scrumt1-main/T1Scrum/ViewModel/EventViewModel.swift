//
//  EventViewModel.swift
//  T1Scrum
//
//  Created by Daniil on 20.08.2021.
//

import Foundation


class EventViewModel: ObservableObject{
    @Published var eventModel: [EventModel] = []
    init(){
        fetchEvents()
    }
    func fetchEvents(){
        self.eventModel = [EventModel(name: "Встреча", card: [CardEventModel(title: "Созвон с покупателем", description: ["- Обсудить стоимость работы", "- Назначить встречу"], dateStart: "20 августа, 17:11", dateEnd: "20 августа, 20:11", staff: [StaffModel(id: 1, firstName: "", lastName: "", middleName: "", email: "", role: RoleModel(name: "", id: 1))])]), EventModel(name: "Митап", card: [CardEventModel(title: "Созвон с покупателем", description: ["- Обсудить стоимость работы", "- Назначить встречу"], dateStart: "20 августа, 17:11", dateEnd: "20 августа, 20:11", staff: [StaffModel(id: 2, firstName: "", lastName: "", middleName: "", email: "", role: RoleModel(name: "", id: 1))])]), EventModel(name: "Тимбилдинг", card: [CardEventModel(title: "Созвон с покупателем", description: ["- Обсудить стоимость работы", "- Назначить встречу"], dateStart: "20 августа, 17:11", dateEnd: "20 августа, 20:11", staff: [StaffModel(id: 3, firstName: "", lastName: "", middleName: "", email: "", role: RoleModel(name: "", id: 1))])])]
    }
}
